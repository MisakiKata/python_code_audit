################################################################################
# IZMSLocale.py
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
################################################################################

# Imports.
from zope.interface import Interface

class IZMSLocale(Interface):

  def get_manage_langs(self):
    """
    Returns list of manage-languages.
    @rtype: C{list}
    """

  def get_manage_lang(self):
    """
    Returns preferred of manage-language for current content-language.
    @rtype: C{string}
    """

  def getZMILangStr(self, key, REQUEST=None, RESPONSE=None):
    """
    Returns language-string for current manage-language.
    @rtype: C{string}
    """

  def getLangStr(self, key, lang=None):
    """
    Returns language-string for given language.
    @rtype: C{string}
    """

  def getPrimaryLanguage(self):
    """
    Returns primary-language of content.
    @rtype: C{string}
    """